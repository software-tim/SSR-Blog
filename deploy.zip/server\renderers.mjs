export { r as renderers } from './chunks/internal_BsTt5pTQ.mjs';
