export { c as createExports, a as start } from './chunks/_@astrojs-ssr-adapter_Cz-38XJL.mjs';
